package hrsm1;


class Node {
 Employee data;
 Node next;

 Node(Employee data) {
     this.data = data;
     next = null;
 }
}